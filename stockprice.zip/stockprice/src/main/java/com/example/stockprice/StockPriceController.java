package com.example.stockprice;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class StockPriceController {
    // These are the labels and button that show data and handle actions
    @FXML
    private Label stockPriceLabel; // Shows the stock price
    @FXML
    private Label stockNameLabel; // Shows the stock name
    @FXML
    private Label stockExchangeLabel; // Shows the stock exchange
    @FXML
    private Label stockUpdatedLabel; // Shows when the stock was last updated
    @FXML
    private Button getStockPriceButton; // Button to get the stock price
    @FXML
    private TextField tickerTextField; // Field where you type the stock symbol

    // This method runs when the controller is first set up
    @FXML
    public void initialize() {
        // When the button is clicked, call the method to get stock price
        getStockPriceButton.setOnAction(event -> fetchStockPrice());
    }

    // This method gets the stock price from the internet
    private void fetchStockPrice() {
        HttpURLConnection connection = null;
        InputStream responseStream = null;

        try {
            // Get the stock symbol from the text field
            String ticker = tickerTextField.getText().trim();
            if (ticker.isEmpty()) {
                stockPriceLabel.setText("Please enter a ticker symbol.");
                return;
            }

            // Set up the URL with the stock symbol
            URL url = new URL("https://api.api-ninjas.com/v1/stockprice?ticker=" + ticker);

            // Open a connection to the URL
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("accept", "application/json");

            // Set the API key for the request
            String apiKey = "rP0gHG+2BLnLs/WKsrBQtg==pnQy5J2c8HBabhZP";
            connection.setRequestProperty("X-Api-Key", apiKey);

            // Check if the response is OK
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                stockPriceLabel.setText("HTTP error code: " + responseCode);
                return;
            }

            // Read the response from the server
            responseStream = connection.getInputStream();
            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(responseStream);

            // Get data from the response
            String name = root.path("name").asText();
            String price = root.path("price").asText();
            String exchange = root.path("exchange").asText();
            String updated = root.path("updated").asText();

            // Update the labels with the stock data
            stockPriceLabel.setText("Stock Price: $" + price);
            stockNameLabel.setText("Name: " + name);
            stockExchangeLabel.setText("Exchange: " + exchange);
            stockUpdatedLabel.setText("Updated: " + updated);

        } catch (Exception e) {
            e.printStackTrace();
            // Show error if something goes wrong
            stockPriceLabel.setText("Error fetching data");
        } finally {
            // Close the connection and response stream
            try {
                if (responseStream != null) {
                    responseStream.close();
                }
                if (connection != null) {
                    connection.disconnect();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

