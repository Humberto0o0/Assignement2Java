package com.example.stockprice;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Load the FXML file that defines the layout
        FXMLLoader loader = new FXMLLoader(getClass().getResource("StockPriceView.fxml"));
        Parent root = loader.load();

        // Create a scene with the size matching the AnchorPane's preferred size
        Scene scene = new Scene(root, 400, 550); // Match these values to the AnchorPane's size

        // Set up the main window
        primaryStage.setTitle("Stock Price Checker"); // Set the window title
        primaryStage.setScene(scene); // Set the scene for the window
        primaryStage.setResizable(false); // Don't allow resizing the window
        primaryStage.show(); // Show the window
    }

    public static void main(String[] args) {
        launch(args); // Start the JavaFX application
    }
}


